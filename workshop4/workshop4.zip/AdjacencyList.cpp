using namespace std;
#include <vector>

int main() {

    vector<vector<int>> adjacencyList = {
        {},
        {2, 3},
        {},
        {2, 4},
        {3}
    };

    return 0;
}

