using namespace std;
#include <vector>

#define X INT_MAX

int main() {

    vector<vector<int>> adjacencyMatrix = {
        {0, X, X, X, X},
        {X, 0, 1, 1, 3},
        {X, 1, 0, 2, X},
        {X, 1, 2, 0, 2},
        {X, 3, X, 2, 0}
    };

    return X;
}

