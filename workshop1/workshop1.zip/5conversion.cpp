#include <bits/stdc++.h>
using namespace std;

int main() {
    string myString = "90";
    int myInt = 239543;

    // 239532 as a string
    string myIntAsString = (string) myInt;

    // 90 as an int
    int myStringAsInt = (int) myString;
}




