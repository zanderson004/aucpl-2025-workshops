#include <bits/stdc++.h>
using namespace std;

int main() {
    int x;
    string y;
    cin >> x >> y;

    if (x % 2 == 0 && y.size() % 2 == 0) {
        cout << "yes\n";
    }
    else {
        cout << "no\n";
    }
}




