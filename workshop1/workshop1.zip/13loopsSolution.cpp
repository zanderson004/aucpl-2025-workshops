#include <bits/stdc++.h>
using namespace std;

int main() {
    string s;
    cin >> s;
    while (s != "stop") {
        cout << s << "\n";
        cin >> s;
    }
}




