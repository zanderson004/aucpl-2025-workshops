#include <bits/stdc++.h>
using namespace std;

int main() {
    string myString = "a string";
    int myInt = 5;
    char myChar = 'a';
    long long myLL = INT_MAX;
    double myDouble = 4.009;

    // What is the error?
    int x = 10;
    int y = 3;
    double quotient = x / y;
    cout << quotient << "\n";
}




