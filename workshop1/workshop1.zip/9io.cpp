#include <bits/stdc++.h>
using namespace std;

int main() {
    cout << setprecision(4) << 3.1415926535 << "\n";

    string string1, string2;
    cin >> string1;
    cin >> string2;

    int x, y, z;
    cin >> x >> y >> z;

    cout << string1 << " " << string2 << "\n";
    cout << x << " " << y << " " << z << "\n";
}




