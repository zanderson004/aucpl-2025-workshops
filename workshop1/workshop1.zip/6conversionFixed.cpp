#include <bits/stdc++.h>
using namespace std;

int main() {
    string myString = "90";
    int myInt = 239543;

    // 239532 as a string
    string myIntAsString = to_string(myInt);

    // 90 as an int
    int myStringAsInt = stoi(myString);
}




